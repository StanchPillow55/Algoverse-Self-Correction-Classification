# Reproduction Instructions for phase1_validation

## Environment Setup

### Option 1: Using Conda
```bash
conda env create -f environment.yml
conda activate teacher-learner-rts
pip install -r requirements.txt
```

### Option 2: Using pip
```bash
pip install -r requirements.txt
```

## Environment Variables

Create a `.env` file with the following API keys:
```
OPENAI_API_KEY=your_openai_key_here
ANTHROPIC_API_KEY=your_anthropic_key_here
HUGGINGFACE_API_KEY=your_huggingface_key_here
REPLICATE_API_TOKEN=your_replicate_token_here
DEMO_MODE=false
```

## Running Experiments

### Phase 1: Validation
```bash
python scripts/run_scaling_simple.py --dataset data/scaling/toolqa_sample.csv --phase 1 --output-dir outputs/phase1_validation --max-turns 2
```

### Phase 2: Medium Scale
```bash
python scripts/run_scaling_simple.py --dataset data/scaling/toolqa_sample.csv --phase 2 --output-dir outputs/phase2_medium_scale --max-turns 3
```

### Phase 3: Full Scale
```bash
python scripts/run_scaling_simple.py --dataset data/scaling/toolqa_sample.csv --phase 3 --output-dir outputs/phase3_full_scale --max-turns 3
```

## Analysis

### Power-Law Analysis
```bash
python -m src.analysis.power_law_analysis
```

### Enhanced Trace Formatting
The enhanced trace formatter will automatically run after each experiment, creating:
- Full reasoning traces as .txt files
- CSV outputs for final answers and multi-turn accuracy
- Summary metrics

## Results Structure

- `results/`: Contains all experiment results
- `outputs/enhanced_traces/`: Contains formatted traces and CSV outputs
- `outputs/scaling_analysis/`: Contains power-law analysis results

## Notes

- All experiments use the same random seed for reproducibility
- API rate limits may affect execution time
- Some models may require specific hardware (e.g., GPU for HuggingFace models)
